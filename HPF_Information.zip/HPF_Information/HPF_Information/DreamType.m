//
//  DreamType.m
//  Uivew
//
//  Created by lanou on 16/5/7.
//  Copyright © 2016年 黄辉. All rights reserved.
//

#import "DreamType.h"

@implementation DreamType

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}
@end
