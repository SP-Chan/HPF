//
//  Dream.m
//  周公解梦
//
//  Created by lanou on 16/3/5.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import "Dream.h"

@implementation Dream

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}

@end
