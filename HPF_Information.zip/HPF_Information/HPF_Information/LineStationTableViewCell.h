//
//  LineStationTableViewCell.h
//  HPF_Information
//
//  Created by XP on 16/5/10.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LineStationTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *stationNumberLabel;
@property (weak, nonatomic) IBOutlet UILabel *stationLabel;

@end
