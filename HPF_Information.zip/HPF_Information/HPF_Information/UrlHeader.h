//
//  UrlHeader.h
//  HPF_Information
//
//  Created by 邓方 on 16/5/5.
//  Copyright © 2016年 HPF. All rights reserved.
//

#ifndef UrlHeader_h
#define UrlHeader_h


//#define LocalNewsUrl @"http://c.3g.163.com/nc/article/local/广州/0-40.html" //本地新闻URL;






#endif /* UrlHeader_h */
