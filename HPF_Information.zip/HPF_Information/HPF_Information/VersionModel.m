//
//  VersionModel.m
//  HPF_Information
//
//  Created by XP on 16/5/14.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "VersionModel.h"

@implementation VersionModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end
