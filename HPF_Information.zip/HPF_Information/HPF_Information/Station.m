//
//  Station.m
//  UI行讯通
//
//  Created by lanou on 16/3/26.
//  Copyright © 2016年 陈少平. All rights reserved.
//

#import "Station.h"

@implementation Station
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"error = %@",key);
}

@end
