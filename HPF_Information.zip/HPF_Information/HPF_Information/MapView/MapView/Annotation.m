//
//  Annotation.m
//  MapView
//
//  Created by XP on 16/5/9.
//  Copyright © 2016年 P. All rights reserved.
//

#import "Annotation.h"

@implementation Annotation

@end
