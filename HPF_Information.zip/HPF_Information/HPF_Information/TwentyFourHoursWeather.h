//
//  TwentyFourHoursWeather.h
//  HPF_Information
//
//  Created by XP on 16/5/4.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseView.h"
#import "HourForWeather.h"
@interface TwentyFourHoursWeather : HPFBaseView

@property(nonatomic,strong)UIScrollView *twenty_fourScroll;

@end
