//
//  AmusementViewController.h
//  HPF_Information
//
//  Created by 邓方 on 16/5/3.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseViewController.h"

@interface AmusementViewController : HPFBaseViewController

@end
