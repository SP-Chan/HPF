//
//  DreamType.h
//  Uivew
//
//  Created by lanou on 16/5/7.
//  Copyright © 2016年 黄辉. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DreamType : NSObject
@property(nonatomic,strong)NSString *title;

@end
