//
//  LeftViewTop.h
//  HPF_Information
//
//  Created by XP on 16/5/3.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseView.h"

@interface LeftViewTop : HPFBaseView

@end
