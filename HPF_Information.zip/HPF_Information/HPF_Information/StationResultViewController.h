//
//  StationResultViewController.h
//  HPF_Information
//
//  Created by XP on 16/5/10.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseViewController.h"

@interface StationResultViewController : HPFBaseViewController
@property(nonatomic,strong)NSString *busName;
@end
