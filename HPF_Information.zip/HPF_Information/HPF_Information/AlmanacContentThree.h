//
//  AlmanacContentThree.h
//  HPF_Information
//
//  Created by lanou on 16/5/4.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import <UIKit/UIKit.h>

#define Width  self.bounds.size.width
#define Height  self.bounds.size.height
@interface AlmanacContentThree : UIView
@property(nonatomic,strong)UIView *LeftView;
@property(nonatomic,strong)UILabel *leftLabel;
@property(nonatomic,strong)UILabel *rightLable;
@property(nonatomic,strong)UIView *RightView;
@end
