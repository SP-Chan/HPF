//
//  ImgModel.m
//  HPF_Information
//
//  Created by 邓方 on 16/5/11.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "ImgModel.h"

@implementation ImgModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
