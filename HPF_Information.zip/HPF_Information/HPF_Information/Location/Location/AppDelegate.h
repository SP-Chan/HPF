//
//  AppDelegate.h
//  Location
//
//  Created by XP on 16/5/6.
//  Copyright © 2016年 P. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

