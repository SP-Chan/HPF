//
//  VideoPlayerViewController.h
//  happysharing
//
//  Created by dengchongkang on 16/3/2.
//  Copyright © 2016年 jackTang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoPlayerViewController : UIViewController
@property(nonatomic,copy) NSString *MP4Url; //获取视频地址;
@property (nonatomic, copy) NSString *videoTitle;


@end
