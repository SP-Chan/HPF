//
//  StationTableViewCell.m
//  UI行讯通
//
//  Created by lanou on 16/3/28.
//  Copyright © 2016年 陈少平. All rights reserved.
//

#import "StationTableViewCell.h"

@implementation StationTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
