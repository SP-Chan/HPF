//
//  LocationViewController.h
//  Happy Sharing
//
//  Created by dengchongkang on 16/3/7.
//  Copyright © 2016年 jackTang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationViewController : UIViewController
@property (nonatomic, copy) NSString *city;
@end
