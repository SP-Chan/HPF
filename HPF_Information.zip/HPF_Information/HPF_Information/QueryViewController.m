//
//  QueryViewController.m
//  HPF_Information
//
//  Created by XP on 16/5/9.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "QueryViewController.h"
#import "ResultViewController.h"
@interface QueryViewController ()<UITextFieldDelegate>
@property(nonatomic,strong)HPFBaseButton *selectButton;
@property(nonatomic,strong)UIAlertController *alert;
@end

@implementation QueryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createSelectView];
    
}

-(void)createSelectView
{
    
    [self.view addSubview:self.textFild];
    [self.view addSubview:self.selectButton];
    
}
-(HPFBaseButton *)selectButton
{
    if (!_selectButton) {
        _selectButton = [HPFBaseButton buttonWithType:UIButtonTypeSystem];
        [_selectButton setTitle:@"查询" forState:UIControlStateNormal];
        _selectButton.frame = CGRectMake((kSCREEN_WIDTH-100)/2, 60, 100, 40);
        _selectButton.backgroundColor = [UIColor redColor];
        _selectButton.layer.cornerRadius = 5;
        _selectButton.layer.masksToBounds = YES;
        [_selectButton addTarget:self action:@selector(selectBuses:) forControlEvents:UIControlEventTouchDown];
//        self.layer.cornerRadius
//        self.layer.masksToBounds
    }
    return _selectButton;
}

-(UITextField *)textFild
{
    if (!_textFild) {
        _textFild = [[UITextField alloc] initWithFrame:CGRectMake(kSCREEN_WIDTH/6, 10, kSCREEN_WIDTH*2/3, 40)];
        _textFild.layer.borderWidth = 1;
        _textFild.layer.borderColor = [UIColor blackColor].CGColor;
        _textFild.placeholder = @"请输入线路名称:";
        _textFild.delegate = self;
    }
    return _textFild;
}

-(void)selectBuses:(HPFBaseButton *)btn
{
    if (_textFild.text.length > 0) {
        ResultViewController *result = [[ResultViewController alloc] init];
        result.busNumber = _textFild.text;
        [self.navigationController pushViewController:result animated:YES];
    }else{
        _alert = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"请正确输入该车信息" preferredStyle:UIAlertControllerStyleAlert];
        
        [self presentViewController:_alert animated:YES completion:^{
            [NSTimer scheduledTimerWithTimeInterval:1.5 target:self selector:@selector(reBack) userInfo:nil repeats:NO];
        }];
    }
}
-(void)reBack
{
    [_alert dismissViewControllerAnimated:YES completion:^{
    
    }];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [_textFild resignFirstResponder];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    return [_textFild resignFirstResponder];
}
         
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
