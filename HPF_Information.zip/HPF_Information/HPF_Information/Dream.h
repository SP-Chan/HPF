//
//  Dream.h
//  周公解梦
//
//  Created by lanou on 16/3/5.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Dream : NSObject

@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *content;
@property(nonatomic,strong)NSString  *parentld;

@end
