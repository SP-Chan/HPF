//
//  VersionModel.h
//  HPF_Information
//
//  Created by XP on 16/5/14.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VersionModel : NSObject
@property(nonatomic,strong)NSString *title;
@property(nonatomic,assign)BOOL isOpen;
@end
