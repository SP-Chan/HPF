//
//  Station.h
//  UI行讯通
//
//  Created by lanou on 16/3/26.
//  Copyright © 2016年 陈少平. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Station : NSObject
@property(nonatomic,strong)NSString *stateName;
@property(nonatomic,strong)NSNumber *station;
@end
