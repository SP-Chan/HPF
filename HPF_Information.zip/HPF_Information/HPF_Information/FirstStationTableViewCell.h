//
//  FirstStationTableViewCell.h
//  UI行讯通
//
//  Created by lanou on 16/3/29.
//  Copyright © 2016年 陈少平. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstStationTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *FirstStitionLabel;
@property (weak, nonatomic) IBOutlet UIImageView *FirstStationImage;


@end
