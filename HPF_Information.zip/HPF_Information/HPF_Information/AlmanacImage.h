//
//  AlmanacImage.h
//  HPF_Information
//
//  Created by lanou on 16/5/4.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlmanacImage : UIView
@property(nonatomic,strong)UIImageView *imageV;
@end
