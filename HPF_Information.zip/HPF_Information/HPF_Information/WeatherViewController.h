//
//  WeatherViewController.h
//  HPF_Information
//
//  Created by 小p on 16/5/4.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseViewController.h"

@interface WeatherViewController : HPFBaseViewController
@property(nonatomic,strong)NSString *city;
@end
