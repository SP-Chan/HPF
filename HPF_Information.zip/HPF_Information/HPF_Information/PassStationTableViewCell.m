//
//  PassStationTableViewCell.m
//  HPF_Information
//
//  Created by XP on 16/5/11.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "PassStationTableViewCell.h"

@implementation PassStationTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
