//
//  HourForWeather.h
//  HPF_Information
//
//  Created by XP on 16/5/4.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseView.h"

@interface HourForWeather : HPFBaseView
@property(nonatomic,strong)UILabel *weatherLabel;
@property(nonatomic,strong)UIImageView *weatherImageV;
@property(nonatomic,strong)UILabel *twenty_fourLabel;
@end
