//
//  TopView.h
//  HPF_Information
//
//  Created by XP on 16/5/10.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseView.h"

@interface TopView : HPFBaseView
@property(nonatomic,strong)HPFBaseButton *reloadButton;
@property(nonatomic,strong)HPFBaseLabel *StartLabel;
@property(nonatomic,strong)HPFBaseLabel *FinalLabel;
@property(nonatomic,strong)HPFBaseLabel *carTitleLabel;




@end
