//
//  TimeLuck.h
//  HPF_Information
//
//  Created by lanou on 16/5/5.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeLuck : NSObject
@property(nonatomic,strong)NSString *des;
@property(nonatomic,strong)NSString *ji;
@property(nonatomic,strong)NSString *yi;
@property(nonatomic,strong)NSString *hours;
@end
