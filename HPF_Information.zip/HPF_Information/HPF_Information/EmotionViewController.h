//
//  EmotionViewController.h
//  HPF_Information
//
//  Created by 邓方 on 16/5/4.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseViewController.h"

@interface EmotionViewController : HPFBaseViewController

@end
