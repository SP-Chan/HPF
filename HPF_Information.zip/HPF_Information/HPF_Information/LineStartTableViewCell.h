//
//  LineStartTableViewCell.h
//  HPF_Information
//
//  Created by XP on 16/5/10.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LineStartTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *stationNumber;
@property (weak, nonatomic) IBOutlet UILabel *stationName;

@end
