//
//  ConstellationViewController.h
//  HPF_Information
//
//  Created by lanou on 16/5/5.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseViewController.h"

@interface ConstellationViewController : HPFBaseViewController

@end
