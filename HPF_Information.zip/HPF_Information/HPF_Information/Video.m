//
//  Video.m
//  HPF_Information
//
//  Created by lanou on 16/5/11.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "Video.h"

@implementation Video
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}
@end
