//
//  StationMessage.h
//  HPF_Information
//
//  Created by XP on 16/5/10.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StationMessage : NSObject
@property(nonatomic,strong)NSString *code;
@property(nonatomic,strong)NSString *stationNum;
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *xy;
@end
