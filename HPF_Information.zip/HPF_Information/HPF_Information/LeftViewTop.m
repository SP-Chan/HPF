//
//  LeftViewTop.m
//  HPF_Information
//
//  Created by XP on 16/5/3.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "LeftViewTop.h"

@implementation LeftViewTop
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {

    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
