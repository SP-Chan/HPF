//
//  AlmanacViewController.h
//  HPF_Information
//
//  Created by XP on 16/4/29.
//  Copyright © 2016年 HPF. All rights reserved.
//

#import "HPFBaseViewController.h"

@interface AlmanacViewController : HPFBaseViewController
@property(nonatomic,strong)NSString *time;
@end
